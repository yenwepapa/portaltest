<?php

namespace App\Service;

use Illuminate\Database\Eloquent\Model;

class TestData extends Model
{
    protected $table = 'testdata';
   
}

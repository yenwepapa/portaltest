<?php $__env->startSection('content'); ?>
<script src="<?php echo e(URL::to('js/datepicker.min.js')); ?>"></script>
<script type="text/javascript">
            $(document).ready(function() {
              $('.datepicker').daterangepicker({
                singleDatePicker: true,
                calender_style: "picker_4",
              })
            });
          </script>

  <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <div class="x_title">
                  <h2>Booking <small>create new</small></h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                      <ul class="dropdown-menu" role="menu">
                        <li><a href="#">Settings 1</a>
                        </li>
                        <li><a href="#">Settings 2</a>
                        </li>
                      </ul>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                  </ul>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                  <br />
                  <?php echo Form::open(array('url'=>'/booking', 'class'=>'form-horizontal form-label-left')); ?>

                    <div class="form-group <?php if($errors->has('room_id')): ?> has-error <?php endif; ?>">
                      <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Room Name</label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <select name="room_id" class="form-control">
                          <?php $room=DB::table('room')->get(); ?>
                          <option>Choose Room</option>
                          <?php foreach($room as $row): ?>
                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                          <?php endforeach; ?>
                        </select>
                        <?php if($errors->has('room_id')): ?><span class="help-inline"> 
                        Rom field is required
                        </span><?php endif; ?>
                      </div>
                    </div>
                    
                    <div class="form-group <?php if($errors->has('start_date')): ?> has-error <?php endif; ?>">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="start_date">Start Date
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12 datepicker" name="start_date">
                        <?php if($errors->has('start_date')): ?><span class="help-inline"> <?php echo $errors->first('start_date'); ?></span><?php endif; ?>
                      </div>
                    </div>
                    <div class="form-group <?php if($errors->has('start_time')): ?> has-error <?php endif; ?>">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="start_time">Start Time
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <select name="start_time" class="form-control">
                            <option>Choose Start Time</option>
                            <?php for ($i=1; $i <=24 ; $i++) { ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                           <?php } ?>
                        </select>
                        <?php if($errors->has('start_time')): ?><span class="help-inline"> <?php echo $errors->first('start_time'); ?></span><?php endif; ?>
                      </div>
                    </div>
                    <div class="form-group <?php if($errors->has('end_date')): ?> has-error <?php endif; ?>">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12 datepicker" for="End Date">End Date
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control col-md-7 col-xs-12 datepicker" name="end_date">
                        <?php if($errors->has('end_date')): ?><span class="help-inline"> <?php echo $errors->first('end_date'); ?></span><?php endif; ?>
                      </div>
                    </div>
                    <div class="form-group <?php if($errors->has('end_time')): ?> has-error <?php endif; ?>">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="end_time">End Time
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <select name="end_time" class="form-control">
                            <option>Choose End Time</option>
                            <?php for ($i=1; $i <=24 ; $i++) { ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                           <?php } ?>
                        </select>
                        <?php if($errors->has('end_time')): ?><span class="help-inline"> <?php echo $errors->first('end_time'); ?></span><?php endif; ?>
                      </div>
                    </div>
                    <div class="form-group <?php if($errors->has('purpose')): ?> has-error <?php endif; ?>">
                      <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Purpose</label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <textarea class="form-control col-md-7 col-xs-12" name="purpose"></textarea>
                        <?php if($errors->has('purpose')): ?><span class="help-inline"> <?php echo $errors->first('purpose'); ?></span><?php endif; ?>
                      </div>
                    </div>
                   
                    <div class="ln_solid"></div>
                    <div class="form-group">
                      <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                        <button type="submit" class="btn btn-primary">Cancel</button>
                        <button type="submit" class="btn btn-success">Submit</button>
                      </div>
                    </div>

                  <?php echo Form::close(); ?>

                </div>
              </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>